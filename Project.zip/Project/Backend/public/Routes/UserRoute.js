// public/Routes/Route.js
const express = require('express');
const router = express.Router();
// Import the getUser function from the controller
const { getUsers  , register , Login} = require('../controller/UserController');  

// Example route
router.route('/').get(getUsers).post(register);
router.route('/Login').get(getUsers).post(Login);






// Export the router
module.exports = router;
