import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Footer from './Component/Footer';
import Home from './Pages/Views/Home';
import About from './Pages/Views/About';
import Service from './Pages/Views/Service';
import Menu from './Pages/Views/Menu';
import Contact from './Pages/Views/Contact';
import Booking from './Pages/Views/Booking';
import Registration from './Pages/Views/Signup';
import ProtectedRoute from './Utilis/Protected'; // ProtectedRoute import karein
import Login from './Pages/Views/Login';

const App = () => {
  return (
    <BrowserRouter>
      {/* Routes ko define karein */}
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<Registration />} />
        <Route path="/Login" element={<Login />} /> {/* Make Login accessible to everyone */}

        {/* Protected routes */}
        <Route element={<ProtectedRoute />}>
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/service" element={<Service />} />
          <Route path="/menu" element={<Menu />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/booking" element={<Booking />} />
        </Route>
      </Routes>

      {/* Footer ko har page pe dikhane ke liye yahan rakhein */}
      <Footer />
    </BrowserRouter>
  );
};

export default App;
