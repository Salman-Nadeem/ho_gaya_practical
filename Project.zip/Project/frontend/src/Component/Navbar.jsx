import React from 'react';
import { Link } from 'react-router-dom';
import '../css/bootstrap.min.css';  // Import Bootstrap CSS Bootstrap JS for navbar functionality
import hero from '../img/hero.png'; // Import the hero image

const Navbar = () => {
  return (
    <div className="hero-header position-relative p-0" style={{ width: '100%' }}>
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top w-100 z-index-3">
        <div className="container">
          <Link to="/" className="navbar-brand p-0">
            <h1 className="text-primary m-0">
              <i className="fa fa-utensils me-3"></i>Restoran
            </h1>
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse"
            aria-controls="navbarCollapse"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="fa fa-bars"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarCollapse">
            <div className="navbar-nav ms-auto py-0 pe-4">
              <Link to="/home" className="nav-item nav-link active">Home</Link>
              <Link to="/about" className="nav-item nav-link">About</Link>
              <Link to="/service" className="nav-item nav-link">Service</Link>
              <Link to="/menu" className="nav-item nav-link">Menu</Link>
              <div className="nav-item dropdown">
             
              </div>
              <Link to="/contact" className="nav-item nav-link">Contact</Link>
            </div>
            <Link to="/booking" className="btn btn-primary py-2 px-4">Book A Table</Link>
          </div>
        </div>
      </nav>

      {/* Hero Section with Overlay */}
      <div className="hero-overlay position-absolute w-100 h-100 top-0 start-0 bg-dark opacity-50 z-index-2"></div>
      
      {/* Hero Content */}
      <div className="container my-5 py-5 position-relative z-index-1">
        <div className="row align-items-center g-5">
          <div className="col-lg-6 text-center text-lg-start">
            <h1 className="display-3 text-white animated slideInLeft">
              Enjoy Our<br />Delicious Meal
            </h1>
            <p className="text-white animated slideInLeft mb-4 pb-2">
              Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet.
            </p>
            <Link to="/booking" className="btn btn-primary py-sm-3 px-sm-5 me-3 animated slideInLeft">
              Book A Table
            </Link>
          </div>
          <div className="col-lg-6 text-center text-lg-end overflow-hidden">
            <img className="img-fluid" src={hero} alt="Hero" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
