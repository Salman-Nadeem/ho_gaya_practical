import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';

const ProtectedRoute = () => {
  const user = localStorage.getItem('user'); // Example: Check if user is authenticated

  if (!user) {
    return <Navigate to="/Login" />;  // Redirect to Login if not authenticated
  }

  return <Outlet />;  // Render the protected route's content if authenticated
};

export default ProtectedRoute;
