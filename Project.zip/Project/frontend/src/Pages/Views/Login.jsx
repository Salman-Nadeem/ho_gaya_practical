import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';  // Import useNavigate for redirection
import axios from 'axios';
import "../../css/style.css";

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [error, setError] = useState('');  // To show error messages
  const navigate = useNavigate();  // Use for navigation

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Send login request to backend
    try {
      const response = await axios.post('http://localhost:5000/login', formData);

      // If login is successful, check the user's role and redirect
      if (response.data.message === "Login successful") {
        const userRole = response.data.userRole;

        // Redirect based on the role
        if (userRole === 'customer') {
          navigate('/home');
        } else {
          navigate('/about');
        }
      }

    } catch (error) {
      // Show error message if login fails
      setError(error.response?.data?.message || "Login failed. Please try again.");
    }
  };

  return (
    <section className="p-5 p-md-6 p-lg-7">
      <div className="container">
        <div className="card border-0 shadow-lg rounded-5">
          <div className="row g-0">
            {/* Left Section: Image and Description */}
            <div className="col-12 col-md-6 bg-gradient text-white rounded-start d-flex align-items-center justify-content-center">
              <div className="text-center p-5">
                <h2 className="display-4 mb-4">Welcome Back</h2>
                <p className="lead mb-5">Log in to access your account and continue where you left off.</p>
              </div>
            </div>

            {/* Right Section: Login Form */}
            <div className="col-12 col-md-6">
              <div className="card-body p-4 p-md-5">
                <h2 className="h3 mb-4">Login</h2>
                <p className="text-muted fs-5 mb-4">Enter your credentials to access your account.</p>

                {/* Show error message if any */}
                {error && <div className="alert alert-danger">{error}</div>}
                
                <form onSubmit={handleSubmit}>
                  <div className="row gy-4">
                    {/* Email Field */}
                    <div className="col-12">
                      <label htmlFor="email" className="form-label">Email Address <span className="text-danger">*</span></label>
                      <input
                        type="email"
                        className="form-control shadow-sm"
                        name="email"
                        id="email"
                        placeholder="name@example.com"
                        value={formData.email}
                        onChange={handleChange}
                        required
                      />
                    </div>

                    {/* Password Field */}
                    <div className="col-12">
                      <label htmlFor="password" className="form-label">Password <span className="text-danger">*</span></label>
                      <input
                        type="password"
                        className="form-control shadow-sm"
                        name="password"
                        id="password"
                        placeholder="******"
                        value={formData.password}
                        onChange={handleChange}
                        required
                      />
                    </div>

                    {/* Submit Button */}
                    <div className="col-12">
                      <div className="d-grid">
                        <button className="btn btn-primary btn-lg shadow-lg hover-shadow" type="submit">
                          Log In
                        </button>
                      </div>
                    </div>
                  </div>
                </form>

                {/* Registration Link */}
                <div className="row mt-4">
                  <div className="col-12 text-center">
                    <p className="text-muted">Don't have an account? <a href="#!" className="link-primary">Sign up</a></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Login;
