const Product = require('../model/Product'); 

const P_Category = require('../model/P_cat'); 

const createProduct = async (req, res) => {
  try {
    const { P_Name, P_Price, P_Category } = req.body;

    // Check if all required fields are provided
    if (!P_Name || !P_Price || !P_Category) {
      return res.status(400).json({ success: false, message: "Name, Price, and Category are required." });
    }

    // Create a new product
    const newProduct = new Product({ P_Name, P_Price, P_Category });

    // Save the product
    const savedProduct = await newProduct.save();

    // Populate the category (P_Category) field with the P_Cat field
    const populatedProduct = await Product.findById(savedProduct._id)
      .populate('P_Category', 'P_Cat');  // Populate only P_Cat field

    // Send the populated product in the response
    return res.status(201).json({
      success: true,
      data: populatedProduct
    });

  } catch (error) {
    return res.status(500).json({ success: false, message: "Error creating product", error: error.message });
  }
};



// READ: Get all products with populated P_Category
const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find().populate('P_Category');  // Ensure P_Category is populated
    return res.json(products);  // Send the populated products data
  } catch (error) {
    console.error('Error fetching products:', error);
    return res.status(500).json({ success: false, message: 'Error fetching products', error: error.message });
  }
};


// READ: Get a single product by ID with populated P_Category
const getProductById = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findById(id).populate('P_Category'); // Ensure this is 'P_Category'
    
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }

    return res.status(200).json({ success: true, data: product });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error fetching product", error: error.message });
  }
};

// UPDATE: Update product by ID with populated P_Category
const updateProductById = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    const updatedProduct = await Product.findByIdAndUpdate(id, updates, { new: true }).populate('P_Category');

    if (!updatedProduct) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }

    return res.json(updatedProduct);
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error updating product", error: error.message });
  }
};

// DELETE: Delete product by ID
const deleteProductById = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedProduct = await Product.findByIdAndDelete(id);

    if (!deletedProduct) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }

    return res.status(200).json({ success: true, message: "Product deleted successfully" });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error deleting product", error: error.message });
  }
};

module.exports = {
  createProduct,
  getAllProducts,
  getProductById,
  updateProductById,
  deleteProductById
};
