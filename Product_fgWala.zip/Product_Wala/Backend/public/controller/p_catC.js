const P_Category = require('../model/P_cat');

// Create Category
const createCategory = async (req, res) => {
  try {
    const { P_Cat, P_Status } = req.body;

    const newCategory = new P_Category({
      P_Cat,
      P_Status
    });

    const savedCategory = await newCategory.save();
    res.status(201).json({ success: true, category: savedCategory });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error creating category', error });
  }
};

// Get All Categories
const getAllCategories = async (req, res) => {
  try {
    const categories = await P_Category.find();
    res.json(categories)
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching categories', error });
  }
};

// Get Category by ID
const getCategoryById = async (req, res) => {
  try {
    const category = await P_Category.findById(req.params.id);
    
    if (!category) {
      return res.status(404).json({ success: false, message: 'Category not found' });
    }

    res.status(200).json({ success: true, category });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching category', error });
  }
};

// Update Category
const updateCategory = async (req, res) => {
  try {
    const updatedCategory = await P_Category.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updatedCategory) {
      return res.status(404).json({ success: false, message: 'Category not found' });
    }

    res.status(200).json({ success: true, category: updatedCategory });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error updating category', error });
  }
};

// Delete Category
const deleteCategory = async (req, res) => {
  try {
    const deletedCategory = await P_Category.findByIdAndDelete(req.params.id);

    if (!deletedCategory) {
      return res.status(404).json({ success: false, message: 'Category not found' });
    }

    res.status(200).json({ success: true, message: 'Category deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error deleting category', error });
  }
};

module.exports = {
  createCategory,
  getAllCategories,
  getCategoryById,
  updateCategory,
  deleteCategory
};
