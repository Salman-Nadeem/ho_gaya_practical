const express = require('express');
const {
    createProduct,
    getAllProducts,
    getProductById,
    updateProductById,
    deleteProductById
} = require('../controller/ProductC');

const router = express.Router();

router.route('/')
    .post(createProduct)
    .get(getAllProducts);

router.route('/:id')
    .get(getProductById)
    .put(updateProductById)
    .delete(deleteProductById);

module.exports = router;
